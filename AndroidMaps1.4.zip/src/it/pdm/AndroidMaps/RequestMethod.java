package it.pdm.AndroidMaps;

public enum RequestMethod
{
    GET,
    POST
}

package it.pdm.AndroidMaps;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TabHost;

public class AugmentedRealityActivity extends Activity {
	
        
        public void onCreate(Bundle savedInstanceState) {
        	super.onCreate(savedInstanceState);
        	setContentView(R.layout.ar);
        	
        }
	
}
